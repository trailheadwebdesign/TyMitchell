import pymysql

USERNAME = 'tym18'
PASSWORD = 'Slidefire556556!'
DATABASE = 'tym18$infs4050'
HOST = 'tym18.mysql.pythonanywhere-services.com'  # Update this to your actual host

try:
    connection = pymysql.connect(
        user=USERNAME,
        password=PASSWORD,
        host=HOST,
        database=DATABASE
    )
    print("Connection successful!")
except pymysql.MySQLError as e:
    print("Connection failed!", e)
finally:
    if 'connection' in locals():
        connection.close()
